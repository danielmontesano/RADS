Comunicaci�n Monoportadora:
- Para ejecutar esta modalidad abrir el archivo "Monoportadora.m". 
  Este programa acceder� a las funciones contenidas en la carpeta Monoportadora.
- Seleccionar el modo de receptor que se desea tener, de acuerdo a los descritos en la memoria:
  Establecer la variable "modo" en:
    '1' Recepci�n no coherente con detecci�n de envolvente
    '2' Recepci�n heterodina no coherente
    '3' Recepci�n heterodina y coherente utilizando PLLs sintonizados
- Para cambiar los par�metros que describen las perturbaciones que afectan a la se�al,
  acceder al archivo "canalTransmisi�n.m"


Comunicaci�n de Expansi�n Espectral:
- Para ejecutar esta modalidad abrir el archivo "ExpansionEspectral.m".
- Ejecutar� las funciones de la carpeta Expansion_Espectral
- Puede cambiar el ruido blanco del canal en el propio archivo "ExpansionEspectral.m".
